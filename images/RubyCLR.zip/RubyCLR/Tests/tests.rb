require 'test/unit'
require 'tests_rbdynamicmethod'
require 'tests_rubyclr'
