require 'rubyclr'

#GC::disable

#RubyClr::reference 'System.Data'

#System::Collections::ArrayList.help('IsFixedSize')
#System::Data::DataSet.help
#System::Data::DataSet.help('Initialized')


System::Xml::XmlTextReader.help
System::Xml::XmlTextReader.help('ReadElementString')
