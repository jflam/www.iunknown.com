﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("TestTargets")]
[assembly: AssemblyDescription("Managed Test Targets for RubyCLR Unit Tests")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ObjectSharp")]
[assembly: AssemblyProduct("TestTargets")]
[assembly: AssemblyCopyright("Copyright © 2005-6 by John Lam")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]