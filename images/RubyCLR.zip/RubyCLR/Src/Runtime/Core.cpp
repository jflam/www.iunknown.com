#include "stdafx.h"

#pragma warning(disable:4947)

#include "RubyHelpers.h"
#include "PerfCounters.h"
#include "Marshal.h"
#include "Wrappers.h"
#include "Reflection.h"
#include "Utility.h"
#include "TestTargets.h"
#include "Core.h"