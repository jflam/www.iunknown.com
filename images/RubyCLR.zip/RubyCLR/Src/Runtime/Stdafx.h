#pragma once

#define _WIN32_WINNT 0x0501
#include <windows.h>
#include <vcclr.h>
#include <ruby.h>

using namespace System;
using namespace System::Collections;
using namespace System::Collections::Generic;
using namespace System::Diagnostics;
using namespace System::Reflection;
using namespace System::Reflection::Emit;
using namespace System::Runtime::InteropServices;
using namespace System::Text;
using namespace System::Text::RegularExpressions;
