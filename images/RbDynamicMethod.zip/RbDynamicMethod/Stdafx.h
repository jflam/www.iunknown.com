#pragma once

#define _WIN32_WINNT 0x0501
#include <windows.h>
#include <vcclr.h>
#include <ruby.h>

