#pragma once

using namespace System::Data;
using namespace System::Drawing;

// TODO: Move all of this stuff to the new RubyClrTests module and port to C#
namespace System {
  public value class MyPoint {
    int x_;
    int y_;
  public:
    MyPoint(Size s) {
      x_ = s.Width;
      y_ = s.Height;
    }

    property int X {
      int get() { return x_; }
      void set(int x) { x_ = x; }
    }

    property int Y {
      int get() { return y_; }
      void set(int y) { y_ = y; }
    }
  };

  public ref class Person {
    String^ name_;
  public:
    Person(String^ name) {
      name_ = name;
    }

    property String^ Name {
      String^ get() { return name_; }
    }

    static Person^ Create() {
      return gcnew Person("John");
    }

    static Person^ Create(String^ name) {
      return gcnew Person(name);
    }
  };

  public ref class MarshalerTests {
  public:
    MarshalerTests() : Name("Hello") {}

    virtual array<int>^ GetOneDimensionalArray() {
      return gcnew array<int> { 0, 1, 2, 3 };
    }

    array<int, 2>^ GetTwoDimensionalArray() {
      return gcnew array<int, 2> { {0, 1}, {1, 0} };
    }

    static array<int>^ StaticGetOneDimensionalArray() {
      return gcnew array<int> { 0, 1, 2, 3 };
    }

    static array<int, 2>^ StaticGetTwoDimensionalArray() {
      return gcnew array<int, 2> { {0, 1}, {1, 0} };
    }

    static array<int, 3>^ StaticGetThreeDimensionalArray() {
      return gcnew array<int, 3> { { {0, 1}, {1, 0} }, { {0, 1}, {1, 0} } };
    }

    Person^ GetPerson() {
      return Person::Create();
    }

    String^ Name;

    static Point UsePoint(Point p) {
      p.X += 1;
      p.Y += 1;
      return p;
    }

    static Point GetPoint() {
      return Point(3, 4);
    }
  };

  public ref class CallbackTests {
  public:
    String^ Name;
    event EventHandler^ Event;

    CallbackTests(String^ name) : Name(name) {}

    void CallMeBack() {
      Event(this, EventArgs::Empty);
    }
  };

  public delegate void AddResultEventHandler(Object^ sender, int result);

  public ref class DelegateCalc {
    int x_;
    int y_;
  public:
    event AddResultEventHandler^ AddResult;  
    DelegateCalc(int x, int y) {
      x_ = x; 
      y_ = y;
    }

    void Add() {
      AddResult(this, x_ + y_);
    }
  };

  public ref class CoVarianceTarget {
  public:
    int Method(String^ value) {
      return 1;
    }

    String^ Method(int value) {
      return "1";
    }

    static int StaticMethod(String^ value) {
      return 1;
    }

    static String^ StaticMethod(int value) {
      return "1";
    }
  };

  public ref class ParentClass {
  public:
    ref class NestedClass {
    public:
      static int Method() {
        return 42;
      }
    };
  };

  public ref class PropertyOverloads {
    array<int>^ _values;
    static int  _value;
    static int  _overloadedValue;
  public:
    PropertyOverloads() {
      _values = gcnew array<int>(10);
    }

    static property int StaticProperty {
      int get() { return _value; }
      void set(int value) { _value = value; }
    }

    static property int OverloadedProperty {
      int get() { return 1; }
    }

    static property int OverloadedProperty[int] {
      int get(int x) { return _overloadedValue; }
      void set(int x, int value) { _overloadedValue = value; }
    }

    property int default[int] {
      int get(int index) { return _values[index]; }
      void set(int index, int value) { _values[index] = value; }
    }

    property int default[String^] {
      int get(String^ index) { return _values[Convert::ToInt32(index)]; }
      void set(String^ index, int value) { _values[Convert::ToInt32(index)] = value; }
    }
  };

  public ref class MethodOverloads {
  public:
    int Method(int p1, Object^ p2) {
      return 1;
    }

    int Method(String^ p1, Object^ p2) {
      return 2;
    }

    int Method(DataColumn^ p1, Object^ p2) {
      return 3;
    }
  };
}

namespace RbDynamicMethodTests {
  public ref class GenericMethodTests {
  public:
    generic <typename T>
    static T Min(T lhs, T rhs) {
      return lhs < rhs ? lhs : rhs;
    }

    generic <typename T>
    static T Min(T a, T b, T c) {
      T lowest = a;
      if (b < lowest) lowest = b;
      if (c < lowest) lowest = c;
      return lowest;
    }

    // This method will expand ambiguously at runtime if we use an Int16 expansion of the above method
    generic <typename T>
    static T Min(T a, T b, short c) {
      T lowest = a;
      if (b < lowest) lowest = b;
      if (c < (int)lowest) lowest = (T)c;
      return (T)42;
    }
  };
}