

I'm keeping this file around to remind me of how far this idea has come since I started this project on Dec 3.

d = DynamicMethod.new(:name => "Bob", :params => "Int32, UInt32*, UInt32")
d = DynamicMethod.new("Int32, UInt32*, UInt32")
g.include "System"
g.exception_block do
  g.call "static Throws.ThrowException()"
  g.br_s "EndOfMethod"
  g.catch("Exception") do
    g.call "ToString()"
    g.call "static Console.WriteLine(String)"
  end
  g.label "EndOfMethod"
  g.ldc_i4 Qnil 
  g.ret
end
d.define_method("call_throw_exception")

call_throw_exception