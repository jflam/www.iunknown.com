#pragma once

using namespace System;
using namespace System::Collections;
using namespace System::Collections::Generic;
using namespace System::Reflection;
using namespace System::Reflection::Emit;
using namespace System::Text::RegularExpressions;

namespace RbDynamicMethod {
  ref class ReflectionHelper {
    static BindingFlags GetBindingFlags(VALUE is_static) {
      bool isStatic;
      if (is_static == Qtrue)
        isStatic = true;
      else if (is_static == Qfalse)
        isStatic = false;
      else
        rb_raise(rb_eArgError, "is_static must be true or false");

      return (isStatic ? BindingFlags::Static : BindingFlags::Instance) | BindingFlags::Public; 
    }

    static Regex^ re = gcnew Regex("^([^\\<]*)(\\<(.*)\\>)?$", RegexOptions::Compiled);

    static String^ ParseTypeRef(String^ type, ArrayList^ namespaces) {
      Match^ m = re->Match(type);
      String^ typeName = m->Groups[1]->Value;
      String^ types    = m->Groups[3]->Value;

      if (types == String::Empty) return typeName;
      array<String^>^ typeNames = types->Split(',');
      int length                = typeNames->Length;
      for (int i = 0; i < length; ++i)
        typeNames[i] = InternalFindType(typeNames[i], namespaces)->FullName;

      return String::Format("{0}`{1}[{2}]", typeName, length, String::Join(", ", typeNames));
    }

    static Type^ FindTypeInAssembly(Assembly^ a, String^ typeName, String^ alternateTypeName) {
      Type^ t = a->GetType(typeName);
      if (t == nullptr && alternateTypeName != String::Empty)
        t = a->GetType(alternateTypeName);  
      return t;
    }

    static Type^ InternalFindType(String^ typeName, ArrayList^ namespaces) {
      // HACK! grotesque hack to get 1 level deep nested classes working for now
      int offset = typeName->LastIndexOf(".");
      String^ alternateTypeName = offset == -1 ? String::Empty : typeName->Substring(0, offset) + "+" + typeName->Substring(offset + 1);

      if (typeName == "VALUE") return UInt32::typeid; // special case
      typeName = ParseTypeRef(typeName, namespaces);
      array<Assembly^>^ assemblies = System::AppDomain::CurrentDomain->GetAssemblies();
      for (int i = 0; i < assemblies->Length; ++i) {
        Type^ t = FindTypeInAssembly(assemblies[i], typeName, alternateTypeName);
        if (t != nullptr) return t;
        if (namespaces != nullptr) {
          // TODO: there is definitely a bug in how namespaces are handled right now - need to track this down
          for (int j = 0; j < namespaces->Count; ++j) {
            //Type^ t = assemblies[i]->GetType(namespaces[j] + "." + typeName);
            //if (t != nullptr) return t;
            // HACK! grotesque hack to get 1 level deep nested classes working for now
            t = FindTypeInAssembly(assemblies[i], namespaces[j] + "." + typeName, namespaces[j] + "." + alternateTypeName);
            if (t != nullptr) return t;
          }
        }
      }
      return nullptr;
    }

    static ArrayList^ GetNamespaces(VALUE self) {
      if (self == Qnil) return nullptr;
      return (ArrayList^)Marshal::ToObject(rb_funcall(self, rb_intern("namespaces"), 0));
    }

  public:
    static array<Type^>^ GetParameterTypes(array<ParameterInfo^>^ signature) {
      array<Type^>^ parameterTypes = gcnew array<Type^>(signature->Length);
      for (int i = 0; i < signature->Length; ++i)
        parameterTypes[i] = signature[i]->ParameterType;
      return parameterTypes;
    }

    static VALUE CreateSignatureArray(array<Type^>^ signature) {
      if (signature == nullptr) return Qnil;
      VALUE signature_array = rb_ary_new2(signature->Length);
      for each (Type^ parameterType in signature) {
        VALUE parameter_type_name = Marshal::ToRubyString(parameterType->FullName);
        rb_ary_push(signature_array, parameter_type_name);
      }
      return signature_array;
    }

    static VALUE CreateSignatureArray(array<array<Type^>^>^ methodTable) {
      if (methodTable == nullptr) return Qnil;
      VALUE signatures = rb_ary_new2(methodTable->Length);
      for each (array<Type^>^ signature in methodTable)
        rb_ary_push(signatures, CreateSignatureArray(signature));
      return signatures;
    }

    static OpCode GetOpCode(VALUE op_code) {
      BindingFlags flags = BindingFlags::IgnoreCase | BindingFlags::Static | BindingFlags::Public;
      String^ opCode = Marshal::ToClrString(op_code);
      if (opCode == "throw_ex") opCode = "throw";  // Workaround since throw is a Ruby keyword
      return (OpCode)OpCodes::typeid->GetField(opCode, flags)->GetValue(nullptr);
    }

    // TODO: should this method cache found types?
    static Type^ FindType(VALUE self, VALUE type_name) {
      Type^ type = InternalFindType(Marshal::ToClrString(type_name), GetNamespaces(self));
      if (type == nullptr) rb_raise(rb_eRuntimeError, "Could not find type: %s", STR2CSTR(type_name));
      return type;
    }

    static Type^ ModuleFindType(VALUE type_name) {
      return FindType(Qnil, type_name);
    }

    static array<Type^>^ GetTypeArrayFromRubyTypeString(VALUE self, VALUE type_string_array) {
      String^ typeStringArray = Marshal::ToClrString(type_string_array);
      if (typeStringArray == String::Empty) return gcnew array<Type^>(0);
      array<String^>^ types = typeStringArray->Split(',');
      array<Type^>^   typeArray = gcnew array<Type^>(types->Length);
      for (int i = 0; i < types->Length; ++i)
        typeArray[i] = InternalFindType(types[i]->Trim(), GetNamespaces(self));
      return typeArray;
    }

    static array<Type^>^ ModuleFindParameterTypes(VALUE method_parameters) {
      return GetTypeArrayFromRubyTypeString(Qnil, method_parameters);
    }

    static MethodInfo^ FindGenericMethodTemplate(Type^ type, String^ methodName, array<Type^>^ paramTypes, 
      VALUE type_name, VALUE method_name, VALUE method_types, VALUE method_parameters) {
      array<MethodInfo^>^ methods = type->GetMethods();
      MethodInfo^ method = nullptr;
      for (int i = 0; i < methods->Length; ++i) {
        array<ParameterInfo^>^ params = methods[i]->GetParameters();
        if (methods[i]->Name == methodName && params->Length == paramTypes->Length) {
          bool match = true;
          for (int j = 0; j < params->Length; ++j) {
            if (params[j]->ParameterType->IsGenericParameter) continue;
            if (params[j]->ParameterType == paramTypes[j]) continue;
            match = false;
            break;
          }
          if (match) {
            if (method == nullptr)
              method = methods[i];
            else
              rb_raise(rb_eRuntimeError, "Ambiguous match exception %s::%s<%s>(%s)", 
                STR2CSTR(type_name), STR2CSTR(method_name), STR2CSTR(method_types), STR2CSTR(method_parameters));
          }
        }
      }
      return method;
    }

    static MethodInfo^ FindMethod(VALUE self, VALUE is_static, VALUE type_name, VALUE method_name, VALUE method_types, VALUE method_parameters) {
      String^ typeName = Marshal::ToClrString(type_name);
      if (typeName == String::Empty) {
        Module^ module = Assembly::GetExecutingAssembly()->GetModules()[0];
        return module->GetMethod(Marshal::ToClrString(method_name));
      }

      Type^ type                = FindType(self, type_name);
      String^ methodName        = Marshal::ToClrString(method_name);
      array<Type^>^ paramTypes  = GetTypeArrayFromRubyTypeString(self, method_parameters);
      MethodInfo^ method        = nullptr;

      if (method_types == Qnil) 
        method = type->GetMethod(methodName, GetBindingFlags(is_static), nullptr, paramTypes, nullptr);
      else {
        array<Type^>^ methodTypes = GetTypeArrayFromRubyTypeString(self, method_types);
        method = FindGenericMethodTemplate(type, methodName, paramTypes, type_name, method_name, method_types, method_parameters)->MakeGenericMethod(methodTypes);
      }

      if (method == nullptr)
        rb_raise(rb_eRuntimeError, "Cannot find method: %s::%s<%s>(%s)",
          STR2CSTR(type_name), STR2CSTR(method_name), STR2CSTR(method_types), STR2CSTR(method_parameters));
      else 
        return method;
    }

    static FieldInfo^ FindField(VALUE self, VALUE is_static, VALUE type_name, VALUE field_name) {
      Type^ type        = FindType(self, type_name);
      String^ fieldName = Marshal::ToClrString(field_name);
      return type->GetField(fieldName, GetBindingFlags(is_static));
    }

    static ConstructorInfo^ FindConstructor(VALUE self, VALUE type_name, VALUE ctor_parameters) {
      Type^ type = FindType(self, type_name);
      return type->GetConstructor(GetBindingFlags(Qfalse), nullptr, GetTypeArrayFromRubyTypeString(self, ctor_parameters), nullptr);     
    }
  };

  ref class LabelDictionary : Dictionary<String^, System::Reflection::Emit::Label> {
  public:
    System::Reflection::Emit::Label GetOrCreateLabel(ILGenerator^ g, VALUE label_name) {
      System::Reflection::Emit::Label label;
      String^ labelName = Marshal::ToClrString(label_name);
      if (!ContainsKey(labelName)) {
        label = g->DefineLabel();
        this[labelName] = label;
      }
      else
        label = this[labelName];
      return label;
    }
  };

  ref class VariableDictionary : Dictionary<String^, LocalBuilder^> {};

  ref class TypeMemberInfo {
    String^               memberTypeName_;
    String^               clrTypeName_;
    String^               rubyMemberName_;
    String^               memberName_;
    array<Type^>^         returnTypes_;
    array<Type^>^         signature_;
    array<array<Type^>^>^ signatures_;
    int                   memberId_;
    Type^                 type_;
    bool                  isSetter_;
    bool                  isIndexer_;
    bool                  isVirtual_;
  public:
    TypeMemberInfo(Type^ type) {
      type_           = type;
      clrTypeName_    = type->FullName;
      rubyMemberName_ = String::Empty;
      memberName_     = String::Empty;
    }

    TypeMemberInfo(Type^ type, String^ memberName) {
      type_           = type;
      clrTypeName_    = type->FullName;
      rubyMemberName_ = memberName;
      memberName_     = memberName;
      isSetter_       = rubyMemberName_->EndsWith("=");
      isIndexer_      = rubyMemberName_->StartsWith("[]");

      if (IsSetter) 
        memberName_ = memberName->Substring(0, memberName->Length - 1);

      if (IsIndexer) {
        if (type->IsArray)
          MemberName = IsSetter ? "Set" : "Get";
        else
          MemberName = "Item";
      }
    }

    property Type^ ClrType {
      Type^ get() { return type_; }
    }

    property bool IsSetter {
      bool get() { return isSetter_; }
    }

    property bool IsIndexer {
      bool get() { return isIndexer_; }
    }

    property array<Type^>^ Signature {
      array<Type^>^ get() { return signature_; }
      void set(array<Type^>^ signature) { signature_ = signature; }
    }

    property array<array<Type^>^>^ Signatures {
      array<array<Type^>^>^ get() { return signatures_; }
      void set(array<array<Type^>^>^ signatures) { signatures_ = signatures; }
    }

    property int MemberId {
      int get() { return memberId_; }
      void set(int memberId) { memberId_ = memberId; }
    };

    property array<Type^>^ ReturnTypes {
      array<Type^>^ get() { return returnTypes_; }
      void set(array<Type^>^ returnTypes) { returnTypes_ = returnTypes; }
    }

    property String^ MemberName {
      String^ get() { return memberName_; }
      void set(String^ memberName) { memberName_ = memberName; }
    }

    property String^ MemberTypeName {
      String^ get() { return memberTypeName_; }
      void set(String^ memberTypeName) { memberTypeName_ = memberTypeName; }
    }

    property bool IsVirtual {
      bool get() { return isVirtual_; }
      void set(bool isVirtual) { isVirtual_ = isVirtual; }
    }
    
    VALUE ReturnMemberInfo() {
      VALUE memberInfoClass = rb_const_get(rb_cObject, rb_intern("MemberInfo"));
      return rb_funcall(memberInfoClass, rb_intern("new"), 9,
        INT2FIX(MemberId), 
        Marshal::ToRubyString(MemberTypeName), 
        Marshal::ToRubyString(MemberName),
        ReflectionHelper::CreateSignatureArray(ReturnTypes),
        ReflectionHelper::CreateSignatureArray(Signature), 
        Marshal::ToRubyString(clrTypeName_),
        Marshal::ToRubyString(rubyMemberName_),
        ReflectionHelper::CreateSignatureArray(Signatures),
        Marshal::ToRubyBoolean(isVirtual_));
    }
  };

  public delegate VALUE RubyMethod(int argc, VALUE *args, VALUE self);

  public ref class MemberRef {};

  public ref class MethodBaseRef : MemberRef {
  protected:
    array<array<Type^>^>^ methodTable_;
    array<Type^>^ returnTypes_;

    void InitializeMethodTable(array<MemberInfo^>^ methods) {
      methodTable_ = gcnew array<array<Type^>^>(methods->Length);
      returnTypes_ = gcnew array<Type^>(methods->Length);

      for (int i = 0; i < methods->Length; ++i) {
        methodTable_[i] = ReflectionHelper::GetParameterTypes(((MethodBase^)methods[i])->GetParameters());
        if(methods[i]->GetType()->FullName == "System.Reflection.RuntimeMethodInfo")
          returnTypes_[i] = ((MethodInfo^)methods[i])->ReturnType;
        else
          returnTypes_[i] = System::Void::typeid;
      }
    }
  public:
    property array<array<Type^>^>^ MethodTable {
      array<array<Type^>^>^ get() { return methodTable_; }
    };
  };

  public ref class MethodRef : MethodBaseRef {
  public:
    MethodRef(array<MemberInfo^>^ methods) {
      InitializeMethodTable(methods);
    }

    property array<Type^>^ ReturnTypes {
      array<Type^>^ get() { return returnTypes_; }
    }
  };

  public ref class ConstructorRef : MethodBaseRef {
  public:
    ConstructorRef(Type^ type) {
      InitializeMethodTable(type->GetConstructors());
    }
  };

  // TODO: not thread safe
  public ref class MetadataCache {
    static List<MemberRef^>^ cache_ = gcnew List<MemberRef^>();
  public:
    static int Add(MemberRef^ member) {
      cache_->Add(member);
      return cache_->Count - 1;
    }

    static property MemberRef^ Item[int] {
      MemberRef^ get(int index) {
        return cache_[index];
      }
    };
  };

  // TODO: Note that this is totally un-optimized. Need to converge on a tree to optimize # tests.
  public ref class RuntimeResolver {
    static Type^ MapRubyTypeToDotNetType(VALUE object) {
      if (object == Qtrue || object == Qfalse)      return bool::typeid;
      if (TYPE(object) == T_STRING)                 return String::typeid;
      if (FIXNUM_P(object))                         return Int32::typeid;
      if (rb_obj_is_kind_of(object, rb_cNumeric))   return Single::typeid; // TODO: make this do single and double somehow ...

      VALUE klass        = rb_class_of(object);
      VALUE class_object = rb_iv_get(klass, "@clr_type");
      return (Type^)Marshal::ToObject(class_object);
    }

    static array<Type^>^ GetParameterTypes(int argc, VALUE *args) {
      array<Type^>^ sig = gcnew array<Type^>(argc);
      for (int i = 0; i < argc; ++i)
        sig[i] = MapRubyTypeToDotNetType(args[i]);
      return sig;
    }

    static bool IsExactMatch(array<Type^>^ rubyParameterTypes, array<Type^>^ methodParameterTypes) {
      if (rubyParameterTypes->Length != methodParameterTypes->Length) return false;
      for (int i = 0; i < rubyParameterTypes->Length; ++i) {
        if (rubyParameterTypes[i] == Single::typeid) {
          if (!(methodParameterTypes[i] == Single::typeid) && !(methodParameterTypes[i] == Double::typeid)) return false;
        }
        else
          if (rubyParameterTypes[i] != methodParameterTypes[i]) return false;
      }
      return true;
    }

    static bool IsMatchParameterArray(array<Type^>^ rubyParameterTypes, array<Type^>^ methodSignatureTypes) {
      Type^ parameterArrayType = methodSignatureTypes[methodSignatureTypes->Length - 1]->GetElementType();
      for (int i = 0; i < rubyParameterTypes->Length; ++i) {
        Type^ lhs = rubyParameterTypes[i];
        if (i < methodSignatureTypes->Length - 1) {
          Type^ rhs = methodSignatureTypes[i];
          if (!(lhs == rhs) && !lhs->IsSubclassOf(rhs)) return false;
        }
        else
          if (!(lhs == parameterArrayType) && !lhs->IsSubclassOf(parameterArrayType)) return false;
      }
      return true;
    }

    // TODO: will eventually have to deal with generics overloads as well
    static int FindBestMatch(array<Type^>^ rubyParameterTypes, array<array<Type^>^>^ methodSignatures, array<bool>^ isParameterArray) {
      int length = rubyParameterTypes->Length;
      for (int i = 0; i < methodSignatures->Length; ++i) {
        array<Type^>^ methodSignature = methodSignatures[i];
        //if (methodSignature->Length <= rubyParameterTypes->Length
        //    && isParameterArray[i] 
        //    && IsMatchParameterArray(rubyParameterTypes, methodSignature)) return i;

        if (length == methodSignature->Length) {
          bool found = true;
          for (int j = 0; j < length; ++j) { 
            Type^ lhs = rubyParameterTypes[j];
            Type^ rhs = methodSignature[j];
            if (lhs != rhs && !lhs->IsSubclassOf(rhs)) {
              found = false;
              break;
            }
          }
          if (found) return i;
        }
      }
      return -1;
    }

    static int FindExactMatch(array<Type^>^ rubyParameterTypes, array<array<Type^>^>^ methodSignatures) {
      for (int i = 0; i < methodSignatures->Length; ++i)
        if (IsExactMatch(rubyParameterTypes, methodSignatures[i])) return i;
      return -1;
    }

  public:
    static int GetMethodTableIndex(int methodId, int argc, VALUE *args) {
      MethodBaseRef^ methodRef     = (MethodBaseRef^)MetadataCache::Item[methodId];      
      array<Type^>^ parameterTypes = GetParameterTypes(argc, args);
      int result                   = FindExactMatch(parameterTypes, methodRef->MethodTable);
      return result == -1 ? FindBestMatch(parameterTypes, methodRef->MethodTable, nullptr) : result;
    }
  };
}