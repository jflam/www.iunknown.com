#pragma once

using namespace System;
using namespace System::Collections;
using namespace System::Reflection;
using namespace System::Reflection::Emit;

VALUE g_module, g_rubyclr, rb_mObjectSpace;

namespace RbDynamicMethod {
  extern "C" {
    VALUE create_dynamic_method(VALUE self, VALUE method_name, VALUE return_type, VALUE method_parameters) {
      Module^ module = Assembly::GetExecutingAssembly()->GetModules()[0];
      String^ name   = method_name == Qnil ? String::Empty : Marshal::ToClrString(method_name);

      DynamicMethod^ method = gcnew DynamicMethod(name, ReflectionHelper::ModuleFindType(return_type), 
                                                  ReflectionHelper::ModuleFindParameterTypes(method_parameters), module);
      return Marshal::ToRubyObjectByRefInternal(method);
    }

    EventInfo^ get_event(VALUE self, VALUE event_name) {
      Type^ type           = Marshal::ToObject(self)->GetType();
      String^ eventName    = Marshal::ToClrString(event_name);
      EventInfo^ eventInfo = type->GetEvent(eventName);
      if (eventInfo == nullptr) throw gcnew Exception("Attempt to bind to non-existent event: " + eventName);
      return eventInfo;
    }

    VALUE create_event_dynamic_method(VALUE self, VALUE event_name) {
      EventInfo^ eventInfo     = get_event(self, event_name);
      MethodInfo^ invokeMethod = eventInfo->EventHandlerType->GetMethod("Invoke");
      Module^ module           = Assembly::GetExecutingAssembly()->GetModules()[0];
      array<Type^>^ paramTypes = ReflectionHelper::GetParameterTypes(invokeMethod->GetParameters());
      DynamicMethod^ method    = gcnew DynamicMethod(String::Empty, invokeMethod->ReturnType, paramTypes, module);

      return Marshal::ToRubyObjectByRefInternal(method);
    }

    VALUE get_cil_generator(VALUE self, VALUE dynamic_method) {
      DynamicMethod^ method = (DynamicMethod^)Marshal::ToObject(dynamic_method);
      return Marshal::ToRubyObjectByRefInternal(method->GetILGenerator());
    }

    ILGenerator^ get_generator(VALUE self) {
      return (ILGenerator^)Marshal::ToObject(rb_funcall(self, rb_intern("generator"), 0));
    }

    LabelDictionary^ get_labels(VALUE self) {
      return (LabelDictionary^)Marshal::ToObject(rb_funcall(self, rb_intern("labels"), 0));
    }

    VariableDictionary^ get_variables(VALUE self) {
      return (VariableDictionary^)Marshal::ToObject(rb_funcall(self, rb_intern("variables"), 0));
    }

    ArrayList^ get_namespaces(VALUE self) {
      if (self == Qnil) return nullptr;
      return (ArrayList^)Marshal::ToObject(rb_funcall(self, rb_intern("namespaces"), 0));
    }

    VALUE create_label_dictionary(VALUE self) {
      return Marshal::ToRubyObjectByRefInternal(gcnew LabelDictionary());
    }

    VALUE create_variable_dictionary(VALUE self) {
      return Marshal::ToRubyObjectByRefInternal(gcnew VariableDictionary());
    }

    VALUE create_namespace_list(VALUE self) {
      ArrayList^ namespaces = gcnew ArrayList();
      namespaces->Add("System");
      namespaces->Add("RbDynamicMethod");
      return Marshal::ToRubyObjectByRefInternal(namespaces);
    }

    // TODO: these two methods are grossly inefficient - looking up each time - yuck. need to eliminate them, but it's easier said
    // then done since they're typically called way up in the metaprogramming cloud
    VALUE is_value_type(VALUE self, VALUE type_name) {
      Type^ type = ReflectionHelper::FindType(self, type_name);
      return type->IsValueType ? Qtrue : Qfalse;
    }

    VALUE is_enum(VALUE self, VALUE type_name) {
      Type^ type = ReflectionHelper::FindType(self, type_name);
      return type->IsEnum ? Qtrue : Qfalse;
    }

    VALUE emit(VALUE self, VALUE op_code) {
      get_generator(self)->Emit(ReflectionHelper::GetOpCode(op_code));
      return Qnil;
    }

    VALUE emit_method_ref(VALUE self, VALUE op_code, VALUE is_static, VALUE type_name, VALUE method_name, VALUE method_types, VALUE method_parameters) {
      MethodInfo^ m = ReflectionHelper::FindMethod(self, is_static, type_name, method_name, method_types, method_parameters);
      // TODO: better error display for a generic method
      if (m == nullptr) 
        rb_raise(rb_eRuntimeError, "Could not find method %s.%s(%s)", STR2CSTR(type_name), STR2CSTR(method_name), STR2CSTR(method_parameters));
      get_generator(self)->Emit(ReflectionHelper::GetOpCode(op_code), m);
      return Qnil;
    }

    VALUE emit_ctor_ref(VALUE self, VALUE op_code, VALUE type_name, VALUE ctor_parameters) {
      ConstructorInfo^ c = ReflectionHelper::FindConstructor(self, type_name, ctor_parameters);
      if (c == nullptr)
        rb_raise(rb_eRuntimeError, "Could not find constructor %s.ctor(%s)", STR2CSTR(type_name), STR2CSTR(ctor_parameters));
      get_generator(self)->Emit(ReflectionHelper::GetOpCode(op_code), c);
      return Qnil;
    }

    VALUE emit_field_ref(VALUE self, VALUE op_code, VALUE is_static, VALUE type_name, VALUE field_name) {
      FieldInfo^ f = ReflectionHelper::FindField(self, is_static, type_name, field_name);
      get_generator(self)->Emit(ReflectionHelper::GetOpCode(op_code), f);
      return Qnil;
    }

    VALUE emit_type_ref(VALUE self, VALUE op_code, VALUE type_name) {
      get_generator(self)->Emit(ReflectionHelper::GetOpCode(op_code), ReflectionHelper::FindType(self, type_name));
      return Qnil;
    }

    VALUE emit_string(VALUE self, VALUE op_code, VALUE string) {
      get_generator(self)->Emit(ReflectionHelper::GetOpCode(op_code), Marshal::ToClrString(string));
      return Qnil;
    }

    VALUE emit_label(VALUE self, VALUE op_code, VALUE label_name) {
      ILGenerator^ g = get_generator(self);
      System::Reflection::Emit::Label label = get_labels(self)->GetOrCreateLabel(g, label_name);
      g->Emit(ReflectionHelper::GetOpCode(op_code), label);
      return Qnil;
    }

    VALUE emit_int64(VALUE self, VALUE op_code, VALUE number) {
      get_generator(self)->Emit(ReflectionHelper::GetOpCode(op_code), rb_num2ll(number));
      return Qnil;
    }

    VALUE emit_int32(VALUE self, VALUE op_code, VALUE number) {
      get_generator(self)->Emit(ReflectionHelper::GetOpCode(op_code), rb_num2long(number));
      return Qnil;
    }

    VALUE emit_int16(VALUE self, VALUE op_code, VALUE number) {
      get_generator(self)->Emit(ReflectionHelper::GetOpCode(op_code), (Int16)rb_num2long(number));
      return Qnil;
    }

    VALUE emit_int8(VALUE self, VALUE op_code, VALUE number) {
      get_generator(self)->Emit(ReflectionHelper::GetOpCode(op_code), (SByte)rb_num2long(number));
      return Qnil;
    }

    VALUE emit_uint8(VALUE self, VALUE op_code, VALUE number) {
      get_generator(self)->Emit(ReflectionHelper::GetOpCode(op_code), (Byte)rb_num2ulong(number));
      return Qnil;
    }

    VALUE emit_double(VALUE self, VALUE op_code, VALUE number) {
      get_generator(self)->Emit(ReflectionHelper::GetOpCode(op_code), NUM2DBL(number));
      return Qnil;
    }

    VALUE emit_local_variable_reference(VALUE self, VALUE op_code, VALUE variable_name) {
      VariableDictionary^ d = get_variables(self);
      LocalBuilder^ variable = d[Marshal::ToClrString(variable_name)];
      get_generator(self)->Emit(ReflectionHelper::GetOpCode(op_code), variable);
      return Qnil;
    }

    VALUE emit_switch_statement(VALUE self, VALUE label_symbols) {
      int length           = RARRAY(label_symbols)->len;
      array<System::Reflection::Emit::Label>^ labels = gcnew array<System::Reflection::Emit::Label>(length);
      LabelDictionary^ d   = get_labels(self);
      ILGenerator^ g       = get_generator(self);

      for(int i = 0; i < length; ++i) {
        VALUE symbol     = rb_ary_entry(label_symbols, i);
        VALUE label_name = rb_funcall(symbol, rb_intern("to_s"), 0);
        labels[i]        = d->GetOrCreateLabel(g, label_name);
      }
      g->Emit(OpCodes::Switch, labels);
      return Qnil;
    }

    VALUE label(VALUE self, VALUE label_name) {
      ILGenerator^ g = get_generator(self);
      VALUE label_name_string = rb_funcall(label_name, rb_intern("to_s"), 0);
      System::Reflection::Emit::Label label = get_labels(self)->GetOrCreateLabel(g, label_name_string);
      g->MarkLabel(label);
      return Qnil;
    }

    void *get_ruby_function_pointer(VALUE klass, VALUE dynamic_method) {
      DynamicMethod^ method     = (DynamicMethod^)Marshal::ToObject(dynamic_method);
      RubyMethod^ rubyMethod    = (RubyMethod^)method->CreateDelegate(RubyMethod::typeid);
      List<Delegate^>^ shimRefs = (List<Delegate^>^)Marshal::ToObject(rb_iv_get(klass, "@shim_refs"));
      if (shimRefs == nullptr) {
        shimRefs        = gcnew List<Delegate^>();
        VALUE shim_refs = Marshal::ToRubyObjectByRefInternal(shimRefs);
        rb_iv_set(klass, "@shim_refs", shim_refs);
      }
      shimRefs->Add(rubyMethod);
      return (void*)System::Runtime::InteropServices::Marshal::GetFunctionPointerForDelegate(rubyMethod);
    }

    VALUE define_ruby_method(VALUE self, VALUE classmod, VALUE dynamic_method, VALUE method_name) {
      rb_define_method(classmod, StringValueCStr(method_name), RUBY_METHOD_FUNC(get_ruby_function_pointer(classmod, dynamic_method)), -1);
      return Qnil;
    }

    VALUE define_ruby_module_function(VALUE self, VALUE module, VALUE dynamic_method, VALUE method_name) {
      rb_define_module_function(module, StringValueCStr(method_name), RUBY_METHOD_FUNC(get_ruby_function_pointer(module, dynamic_method)), -1);
      return Qnil;
    }

    VALUE define_ruby_singleton_method(VALUE self, VALUE classmod, VALUE dynamic_method, VALUE method_name) {
      rb_define_singleton_method(classmod, StringValueCStr(method_name), RUBY_METHOD_FUNC(get_ruby_function_pointer(classmod, dynamic_method)), -1);
      return Qnil;
    }

    VALUE define_event_method(VALUE self, VALUE dynamic_method, VALUE event_name) {
      EventInfo^ eventInfo  = get_event(self, event_name);
      DynamicMethod^ method = (DynamicMethod^)Marshal::ToObject(dynamic_method);
      eventInfo->AddEventHandler(Marshal::ToObject(self), method->CreateDelegate(eventInfo->EventHandlerType));
      return Qnil;
    }

    VALUE append_namespaces(VALUE self, VALUE namespaces) {
      array<String^>^ namespace_vector = Marshal::ToClrString(namespaces)->Split(',');
      get_namespaces(self)->AddRange(namespace_vector);     
      return Qnil;
    }

    VALUE declare(VALUE self, VALUE type_name, VALUE variable_symbol) {
      LocalBuilder^ variable = get_generator(self)->DeclareLocal(ReflectionHelper::FindType(self, type_name));
      VALUE variable_name = rb_funcall(variable_symbol, rb_intern("to_s"), 0);
      String^ name = Marshal::ToClrString(variable_name);
      get_variables(self)->Add(name, variable);
      return Qnil;
    }

    VALUE begin_exception_block(VALUE self) {
      get_generator(self)->BeginExceptionBlock();
      return Qnil;
    }

    VALUE begin_catch_block(VALUE self, VALUE type_name) {
      get_generator(self)->BeginCatchBlock(ReflectionHelper::FindType(self, type_name));
      return Qnil;
    }
    
    VALUE end_exception_block(VALUE self) {
      get_generator(self)->EndExceptionBlock();
      return Qnil;
    }

    VALUE ld_block(VALUE self, VALUE block) {
      get_generator(self)->Emit(OpCodes::Ldc_I4, (int)block);
      return Qnil;
    }

    VALUE intern(VALUE self, VALUE string) {
      get_generator(self)->Emit(OpCodes::Ldc_I4, (int)rb_intern(StringValueCStr(string)));
      return Qnil;
    }

    VALUE call_ruby_varargs(VALUE self, VALUE method_name, VALUE parameter_count) {
      Module^ module             = Assembly::GetExecutingAssembly()->GetModules()[0];
      MethodInfo^ method         = module->GetMethod(Marshal::ToClrString(method_name));
      int parameterCount         = Marshal::ToInt32(parameter_count);
      array<Type^>^ varargsTypes = gcnew array<Type^>(parameterCount);
      for (int i = 0; i < parameterCount; ++i)
        varargsTypes[i] = System::UInt32::typeid;
      get_generator(self)->EmitCall(OpCodes::Call, method, varargsTypes);
      return Qnil;
    }

    VALUE call_ruby(VALUE self, VALUE method_name) {
      Module^ module     = Assembly::GetExecutingAssembly()->GetModules()[0];
      MethodInfo^ method = module->GetMethod(Marshal::ToClrString(method_name));
      get_generator(self)->Emit(OpCodes::Call, method);
      return Qnil;
    }

    VALUE clone_value_type(VALUE self) {
      VALUE clone       = rb_obj_clone(self);
      VALUE klass       = rb_class_of(self);
      int valueTypeSize = FIX2LONG(rb_iv_get(klass, "@value_type_size"));

      void *cloneData   = ruby_xmalloc(valueTypeSize);
      memcpy(cloneData, DATA_PTR(self), valueTypeSize);
      DATA_PTR(clone)   = cloneData;

      return clone;
    }

    // Bridge methods
    VALUE create_clr_class_object(VALUE self, VALUE class_name) {
      VALUE class_object  = rb_funcall(rb_cClass, rb_intern("new"), 0);
      rb_iv_set(class_object, "@clr_type_name", class_name);

      VALUE shim_refs = Marshal::ToRubyObjectByRefInternal(gcnew List<Delegate^>());
      rb_iv_set(class_object, "@shim_refs", shim_refs);

      Type^ type = ReflectionHelper::FindType(Qnil, class_name);
      rb_iv_set(class_object, "@clr_type",      Marshal::ToRubyObjectByRefInternal(type));
      rb_iv_set(class_object, "@is_value_type", type->IsValueType ? Qtrue : Qfalse);
      rb_iv_set(class_object, "@is_enum",       type->IsEnum ? Qtrue : Qfalse);

      if (type->IsValueType) {
        int valueTypeSize = type->IsEnum ? 4 : System::Runtime::InteropServices::Marshal::SizeOf(type);
        rb_iv_set(class_object, "@value_type_size", INT2FIX(valueTypeSize));
        rb_define_method(class_object, "clone", RUBY_METHOD_FUNC(clone_value_type), 0);
      }

      rb_define_alloc_func(class_object, alloc_clr_object);
      
      // TODO: perhaps should move this cache add somewhere else?
      Marshal::TypeNameToClassObject.Add(Marshal::ToClrString(class_name), class_object);

      rb_funcall(class_object, rb_intern("extend"), 1, rb_const_get(rb_cObject, rb_intern("ClrClassStaticMethods"))); 
      return class_object;
    }

    void internal_get_array_info(TypeMemberInfo^ typeMemberInfo, array<MemberInfo^>^ methodInfo) {
      typeMemberInfo->MemberTypeName = "array";
      MethodRef^ methodRef           = gcnew MethodRef(methodInfo);
      typeMemberInfo->ReturnTypes    = methodRef->ReturnTypes;
      typeMemberInfo->Signature      = methodRef->MethodTable[0];
    }

    void internal_get_property_info(TypeMemberInfo^ typeMemberInfo, array<MemberInfo^>^ propertyInfos) {
      List<MethodInfo^>^ methodInfos = gcnew List<MethodInfo^>();
      for each (PropertyInfo^ propertyInfo in propertyInfos) {
        MethodInfo^ methodInfo = typeMemberInfo->IsSetter ? propertyInfo->GetSetMethod() : propertyInfo->GetGetMethod();
        if (methodInfo != nullptr) methodInfos->Add(methodInfo);
      }

      MethodRef^ methodRef = gcnew MethodRef(methodInfos->ToArray());

      typeMemberInfo->MemberName  = typeMemberInfo->IsSetter ? "set_" + typeMemberInfo->MemberName : "get_" + typeMemberInfo->MemberName;
      typeMemberInfo->ReturnTypes = methodRef->ReturnTypes;
      typeMemberInfo->IsVirtual   = ((MethodInfo^)methodInfos[0])->IsVirtual;

      if (methodInfos->Count == 1) {
        typeMemberInfo->MemberTypeName = "fastproperty";
        typeMemberInfo->Signature      = methodRef->MethodTable[0];
      }
      else {
        typeMemberInfo->MemberTypeName = "property";
        typeMemberInfo->Signatures     = methodRef->MethodTable; 
        typeMemberInfo->MemberId       = MetadataCache::Add(methodRef);
      }
    }

    void internal_get_method_info(TypeMemberInfo^ typeMemberInfo, array<MemberInfo^>^ methodInfo) {
      MethodRef^ methodRef = gcnew MethodRef(methodInfo);

      typeMemberInfo->ReturnTypes = methodRef->ReturnTypes;
      // TODO: make this an array of is_virtual flags, since each method may or may not be virtual
      typeMemberInfo->IsVirtual   = ((MethodInfo^)methodInfo[0])->IsVirtual;

      if (methodRef->MethodTable->Length == 1) {
        typeMemberInfo->MemberTypeName = "fastmethod";
        typeMemberInfo->Signature      = methodRef->MethodTable[0];
      }
      else {
        typeMemberInfo->MemberTypeName = "method";
        typeMemberInfo->Signatures     = methodRef->MethodTable;
        typeMemberInfo->MemberId       = MetadataCache::Add(methodRef);
      }
    }

    void internal_get_event_info(TypeMemberInfo^ typeMemberInfo, EventInfo^ eventInfo) {
      typeMemberInfo->MemberTypeName = "event";
      MethodInfo^ invokeMethod       = eventInfo->EventHandlerType->GetMethod("Invoke");
      typeMemberInfo->Signature      = ReflectionHelper::GetParameterTypes(invokeMethod->GetParameters());
      typeMemberInfo->ReturnTypes    = gcnew array<Type^> { invokeMethod->ReturnType };
    }

    void internal_get_field_info(TypeMemberInfo^ typeMemberInfo, FieldInfo^ fieldInfo) {
      typeMemberInfo->MemberTypeName = "field";
      typeMemberInfo->ReturnTypes    = gcnew array<Type^> { fieldInfo->FieldType };
    }

    VALUE internal_get_member_info(Type^ type, VALUE member_name, bool isStatic) {
      TypeMemberInfo^ typeMemberInfo = gcnew TypeMemberInfo(type, Marshal::ToClrString(member_name));

      BindingFlags flags = BindingFlags::Public | (isStatic ? BindingFlags::Static : BindingFlags::Instance);
      array<MemberInfo^>^ members = type->GetMember(typeMemberInfo->MemberName, flags);
      if (members->Length == 0) 
        throw gcnew Exception(String::Format("Member {0} not found in type {1}", typeMemberInfo->MemberName, type->FullName));

      // TODO: this is very sub-optimal way of detecting RuntimeMethodInfo types - is there a better way?
      String^ memberTypeName = members[0]->GetType()->FullName;
      if (type->IsArray && typeMemberInfo->IsIndexer)
        internal_get_array_info(typeMemberInfo, members);
      else if (memberTypeName == "System.Reflection.RuntimePropertyInfo")
        internal_get_property_info(typeMemberInfo, members);
      else if (memberTypeName == "System.Reflection.RtFieldInfo") 
        internal_get_field_info(typeMemberInfo, (FieldInfo^)members[0]);
      else if (memberTypeName == "System.Reflection.RuntimeEventInfo")
        internal_get_event_info(typeMemberInfo, (EventInfo^)members[0]);
      else if (memberTypeName == "System.Reflection.RuntimeMethodInfo")
        internal_get_method_info(typeMemberInfo, members);

      return typeMemberInfo->ReturnMemberInfo();
    }

    VALUE get_instance_member_info(VALUE self, VALUE member_name) {
      VALUE klass        = rb_class_of(self);
      VALUE class_object = rb_iv_get(klass, "@clr_type");
      Type^ type         = (Type^)Marshal::ToObject(class_object);
      return internal_get_member_info(type, member_name, false);
    }

    VALUE get_static_member_info(VALUE self, VALUE member_name) {
      Type^ type = (Type^)Marshal::ToObject(rb_iv_get(self, "@clr_type"));
      return internal_get_member_info(type, member_name, true);
    }

    VALUE get_constructor_info(VALUE self, VALUE klass) {
      Type^ type                     = (Type^)Marshal::ToObject(rb_iv_get(klass, "@clr_type"));
      TypeMemberInfo^ typeMemberInfo = gcnew TypeMemberInfo(type);

      ConstructorRef^ constructorRef = gcnew ConstructorRef(type);
      if (constructorRef->MethodTable->Length == 1) {
        typeMemberInfo->MemberTypeName = "fastctor";
        typeMemberInfo->Signature      = constructorRef->MethodTable[0];
      }
      else {
        typeMemberInfo->MemberTypeName = "ctor";
        typeMemberInfo->Signatures     = constructorRef->MethodTable;
        typeMemberInfo->MemberId       = MetadataCache::Add(constructorRef);
      }
      return typeMemberInfo->ReturnMemberInfo();
    }

    VALUE get_array_of_full_type_names(Assembly^ assembly, VALUE type_names) {
      array<Type^>^ types = assembly->GetTypes();
      for each(Type^ type in types)
        rb_ary_push(type_names, Marshal::ToRubyString(type->FullName));
      return type_names;
    }

    VALUE get_types_in_loaded_assemblies(VALUE self) {
      VALUE type_names             = rb_ary_new();
      array<Assembly^>^ assemblies = System::AppDomain::CurrentDomain->GetAssemblies();
      for each (Assembly^ assembly in assemblies)
        get_array_of_full_type_names(assembly, type_names);
      return type_names;
    }

    VALUE reference(VALUE self, VALUE assembly_name) {
      String^ assemblyName = gcnew String(STR2CSTR(assembly_name));
      Assembly^ assembly   = Assembly::LoadWithPartialName(assemblyName);
      if (assembly == nullptr)
        rb_raise(rb_eArgError, "%s is not an assembly name", STR2CSTR(assembly_name));
      return get_array_of_full_type_names(assembly, rb_ary_new());    
    }

    VALUE reference_file(VALUE self, VALUE assembly_path) {
      String^ assemblyFileName = gcnew String(STR2CSTR(assembly_path));
      Assembly^ assembly       = Assembly::LoadFrom(assemblyFileName);
      if (assembly == nullptr)
        rb_raise(rb_eArgError, "%s is not an assembly name", STR2CSTR(assembly_path));
      return get_array_of_full_type_names(assembly, rb_ary_new());    
    }

    VALUE get_enum_names(VALUE self, VALUE klass) {
      VALUE names = rb_ary_new();
      Type^ type  = (Type^)Marshal::ToObject(rb_iv_get(klass, "@clr_type"));
      for each(String^ enumName in Enum::GetNames(type))
        rb_ary_push(names, Marshal::ToRubyString(enumName));
      return names;
    }

    VALUE get_enum_values(VALUE self, VALUE klass) {
      VALUE values = rb_ary_new();
      Type^ type   = (Type^)Marshal::ToObject(rb_iv_get(klass, "@clr_type"));
      for each(int enumValue in Enum::GetValues(type))
        rb_ary_push(values, Marshal::ToRubyNumber(enumValue));
      return values;
    }

    void Managed_Init_RbDynamicMethod() {
      g_module = rb_define_module("RbDynamicMethod");

      rb_define_module_function(g_module, "create_dynamic_method", RUBY_METHOD_FUNC(create_dynamic_method), 3);
      rb_define_module_function(g_module, "create_event_dynamic_method", RUBY_METHOD_FUNC(create_event_dynamic_method), 1);
      rb_define_module_function(g_module, "get_cil_generator", RUBY_METHOD_FUNC(get_cil_generator), 1);
      rb_define_module_function(g_module, "create_label_dictionary", RUBY_METHOD_FUNC(create_label_dictionary), 0);
      rb_define_module_function(g_module, "create_variable_dictionary", RUBY_METHOD_FUNC(create_variable_dictionary), 0);
      rb_define_module_function(g_module, "create_namespace_list", RUBY_METHOD_FUNC(create_namespace_list), 0);
      rb_define_module_function(g_module, "is_value_type?", RUBY_METHOD_FUNC(is_value_type), 1);
      rb_define_module_function(g_module, "is_enum?", RUBY_METHOD_FUNC(is_enum), 1);
      rb_define_module_function(g_module, "emit", RUBY_METHOD_FUNC(emit), 1);
      rb_define_module_function(g_module, "emit_method_ref", RUBY_METHOD_FUNC(emit_method_ref), 6);
      rb_define_module_function(g_module, "emit_ctor_ref", RUBY_METHOD_FUNC(emit_ctor_ref), 3);
      rb_define_module_function(g_module, "emit_field_ref", RUBY_METHOD_FUNC(emit_field_ref), 4);
      rb_define_module_function(g_module, "emit_type_ref", RUBY_METHOD_FUNC(emit_type_ref), 2);
      rb_define_module_function(g_module, "emit_string", RUBY_METHOD_FUNC(emit_string), 2);
      rb_define_module_function(g_module, "emit_label", RUBY_METHOD_FUNC(emit_label), 2);
      rb_define_module_function(g_module, "emit_int64", RUBY_METHOD_FUNC(emit_int64), 2);
      rb_define_module_function(g_module, "emit_int32", RUBY_METHOD_FUNC(emit_int32), 2);
      rb_define_module_function(g_module, "emit_int16", RUBY_METHOD_FUNC(emit_int16), 2);
      rb_define_module_function(g_module, "emit_int8", RUBY_METHOD_FUNC(emit_int8), 2);
      rb_define_module_function(g_module, "emit_uint8", RUBY_METHOD_FUNC(emit_uint8), 2);
      rb_define_module_function(g_module, "emit_double", RUBY_METHOD_FUNC(emit_double), 2);
      rb_define_module_function(g_module, "emit_local_variable_reference", RUBY_METHOD_FUNC(emit_local_variable_reference), 2);
      rb_define_module_function(g_module, "emit_switch_statement", RUBY_METHOD_FUNC(emit_switch_statement), 1);
      rb_define_module_function(g_module, "define_ruby_method", RUBY_METHOD_FUNC(define_ruby_method), 3);
      rb_define_module_function(g_module, "define_ruby_module_function", RUBY_METHOD_FUNC(define_ruby_module_function), 3);
      rb_define_module_function(g_module, "define_ruby_singleton_method", RUBY_METHOD_FUNC(define_ruby_singleton_method), 3);
      rb_define_module_function(g_module, "define_event_method", RUBY_METHOD_FUNC(define_event_method), 2);
      rb_define_module_function(g_module, "append_namespaces", RUBY_METHOD_FUNC(append_namespaces), 1);
      rb_define_module_function(g_module, "label", RUBY_METHOD_FUNC(label), 1);
      rb_define_module_function(g_module, "declare", RUBY_METHOD_FUNC(declare), 2);
      rb_define_module_function(g_module, "try", RUBY_METHOD_FUNC(begin_exception_block), 0);
      rb_define_module_function(g_module, "catch_ex", RUBY_METHOD_FUNC(begin_catch_block), 1);
      rb_define_module_function(g_module, "end_try", RUBY_METHOD_FUNC(end_exception_block), 0);
      rb_define_module_function(g_module, "ld_block", RUBY_METHOD_FUNC(ld_block), 1);
      rb_define_module_function(g_module, "intern", RUBY_METHOD_FUNC(intern), 1);
      rb_define_module_function(g_module, "call_ruby_varargs", RUBY_METHOD_FUNC(call_ruby_varargs), 2);
      rb_define_module_function(g_module, "call_ruby", RUBY_METHOD_FUNC(call_ruby), 1);

      rb_define_module_function(g_module, "create_clr_class_object", RUBY_METHOD_FUNC(create_clr_class_object), 1);
      rb_define_module_function(g_module, "get_constructor_info", RUBY_METHOD_FUNC(get_constructor_info), 1);
      rb_define_module_function(g_module, "get_static_member_info", RUBY_METHOD_FUNC(get_static_member_info), 1);
      rb_define_module_function(g_module, "get_instance_member_info", RUBY_METHOD_FUNC(get_instance_member_info), 1);
      rb_define_module_function(g_module, "get_enum_names", RUBY_METHOD_FUNC(get_enum_names), 1);
      rb_define_module_function(g_module, "get_enum_values", RUBY_METHOD_FUNC(get_enum_values), 1);
    
      g_rubyclr = rb_define_module("RubyClr");
      rb_define_module_function(g_rubyclr, "internal_reference", RUBY_METHOD_FUNC(reference), 1);
      rb_define_module_function(g_rubyclr, "internal_reference_file", RUBY_METHOD_FUNC(reference_file), 1);
      rb_define_module_function(g_rubyclr, "get_types_in_loaded_assemblies", RUBY_METHOD_FUNC(get_types_in_loaded_assemblies), 0);

      rb_require("ruby_dynamic_method.rb");
    }
#pragma unmanaged
    // Main entry point
    __declspec(dllexport) void Init_RbDynamicMethod() {
      CoInitializeEx(0, COINIT_APARTMENTTHREADED);
      Managed_Init_RbDynamicMethod();
    }
  }
}