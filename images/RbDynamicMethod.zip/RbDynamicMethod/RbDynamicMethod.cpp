#include "stdafx.h"

#pragma warning(disable:4947)

#include "Marshal.h"
#include "MemberCache.h"
#include "ManagedTestTargets.h"
#include "RbDynamicMethod.h"
