module RbTokenParser
  @@method_ref_re = /^(static )?([\w_\.\<\>\[\]\,\+]*)::([\w_]+)(\<(.*)\>)?\((.*)\)$/
  @@field_ref_re  = /^(static )?([\w_\.\<\>\+]*)::([\w_]+)$/
  @@ctor_ref_re   = /^([\w_\.\<\>\+]*)\((.*)\)$/
  @@type_ref_re   = /^([\w_\.\+]*)(\<(.*)\>)?$/

  def self.is_method_ref?(sig)
    @@method_ref_re.match(sig) != nil
  end

  def self.parse_method_or_ctor_ref(sig)
    m = @@method_ref_re.match(sig)
    if m == nil
      m = @@ctor_ref_re.match(sig)
      raise "Invalid method or constructor signature #{sig}" if m == nil
      type_name, parameters = m[1], m[2]
      return 'ctor', type_name, parameters
    else
      is_static = m[1] == 'static '
      type_name, method_name, method_types, parameters = m[2], m[3], m[5], m[6]
      return 'method', is_static, type_name, method_name, method_types, parameters
    end
  end
  
  def self.parse_method_ref(sig)
    m = @@method_ref_re.match(sig)
    raise "Invalid method signature #{sig}" if m == nil
    is_static = m[1] == 'static '
    type_name, method_name, method_types, parameters = m[2], m[3], m[5], m[6]
    return is_static, type_name, method_name, method_types, parameters
  end

  def self.is_field_ref?(sig)
    @@field_ref_re.match(sig) != nil
  end

  def self.parse_field_ref(sig)
    m = @@field_ref_re.match(sig)
    raise "Invalid field signature #{sig}" if m == nil
    is_static = m[1] == 'static '
    type_name, field_name = m[2], m[3]
    return is_static, type_name, field_name
  end

  def self.parse_ctor_ref(sig)
    m = @@ctor_ref_re.match(sig)
    raise "Invalid constructor signature #{sig}" if m == nil
    type_name, parameters = m[1], m[2]
    return type_name, parameters
  end

  def self.is_type_ref?(sig)
    @@type_ref_re.match(sig) != nil
  end

  def self.parse_type_ref(sig)
    m = @@type_ref_re.match(sig)
    raise "Invalid type signature: #{sig}" if m == nil
    type_name, types = m[1], m[3]
    if types == nil
      type_name
    else
      type_list = types.split(',').collect { |t| t.strip }
      "#{type_name}`#{type_list.length}[#{type_list.join(',')}]"
    end
  end
end
