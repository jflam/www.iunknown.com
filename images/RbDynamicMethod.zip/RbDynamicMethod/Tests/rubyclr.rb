require 'RbDynamicMethod'
include RbDynamicMethod

MemberInfo = Struct.new(:member_id, :member_type, :member_name, :return_types, :signature, :clr_type, :ruby_member_name, :signatures, :is_virtual)

class Object
  def auto_dispose(obj)
    yield obj if block_given?
    obj.Dispose
  end
  
  def auto_close(obj)
    yield obj if block_given?
    obj.Close
  end
  
  def marshal_to_data_table(array)
    dt = DataTable.new
    raise 'array must have at least one element' if array.length < 1
    schema = array[0].members
    schema.each { |column_name| dt.Columns.Add(column_name) }
    array.each do |element|
      row = dt.NewRow
      schema.each do |column_name| 
        row[column_name] = element.send column_name
      end
      dt.Rows.Add(row)
    end
    dt
  end
end
  
module ClrClassInstanceMethods
  def generate_ctor_shim(klass, ctor_info)
    ctor_labels   = (1..ctor_info.signatures.length).collect { |i| ("l" + i.to_s).to_sym }
    is_value_type = klass.is_value_type? 
    
    create_safe_ruby_instance_method(klass, 'initialize') do
      declare     ctor_info.clr_type, :obj
      
      match_sig   ctor_info.member_id
      switch      ctor_labels
      throw_clr   'Cannot find method that matches Ruby parameters'
      
      if is_value_type
        ctor_info.signatures.each_with_index do |sig, i|
          label       ctor_labels[i]
          ldloca_s    :obj
          ld_params   sig
          call        ctor_info.clr_type + '(' + sig.join(',') + ')'
          br          :end_switch
        end
        
        label         :end_switch
        ret_valuetype :obj, ctor_info.clr_type
      else
        ctor_info.signatures.each_with_index do |sig, i|
          label       ctor_labels[i]
          ld_params   sig
          new_clrobj  ctor_info, sig
          stloc_s     :obj
          br          :end_switch
        end
        
        label         :end_switch
        ret_objref    :obj
      end
    end
  end
  
  def generate_fastctor_shim(klass, ctor_info)
    is_value_type = klass.is_value_type? 
    
    create_safe_ruby_instance_method(klass, 'initialize') do
      declare     ctor_info.clr_type, :obj
      
      if is_value_type
        ldloca_s       :obj
        ld_params      ctor_info.signature
        call           ctor_info.clr_type + '(' + ctor_info.signature.join(',') + ')'
        ret_valuetype  :obj, ctor_info.clr_type
      else
        ld_params      ctor_info.signature
        new_clrobj     ctor_info
        stloc_s        :obj
        ret_objref     :obj
      end
    end
  end
  
  def initialize(*params)
    ctor_info = get_constructor_info(self.class)
    
    case ctor_info.member_type
    when 'ctor':     generate_ctor_shim(self.class, ctor_info)
    when 'fastctor': generate_fastctor_shim(self.class, ctor_info)
    end
    
    initialize(*params)
  end

  def generate_fastmethod_shim(klass, method_info)
    create_safe_ruby_instance_method(klass, method_info.ruby_member_name) do
      ld_this      klass
      ld_params    method_info.signature
      inst_call    method_info
      ret_2rb      method_info
    end
  end
  
  def generate_method_shim(klass, method_info)
    method_labels = (1..method_info.signatures.length).collect { |i| ("l" + i.to_s).to_sym }
    
    create_safe_ruby_instance_method(klass, method_info.ruby_member_name) do
      match_sig   method_info.member_id
      switch      method_labels
      throw_clr   'Cannot find method that matches Ruby parameters'

      method_info.signatures.each_with_index do |sig, i|
        label      method_labels[i]
        
        ld_this    klass
        ld_params  sig
        inst_call  method_info, sig
        ret_2rb    method_info, i
      end
    end
  end
  
  def generate_event_shim(klass, event_info, &block)
    create_event_shim(klass, event_info.member_name) do
      ld_block      block
      intern        'call'
      ldc_i4        event_info.signature.length
      event_info.signature.each_with_index do |type, i|
        ldarg_s     i
        marshal2rb  type
      end
      call_ruby_varargs  'rb_funcall', event_info.signature.length
      marshal2clr        event_info.return_types[0]
      ret
    end
  end
  
  def generate_field_shim(klass, field_info)
    is_setter = field_info.ruby_member_name.rindex('=') == (field_info.ruby_member_name.length - 1)
    create_safe_ruby_instance_method(klass, field_info.ruby_member_name) do
      if is_setter
        ld_this      klass
        ld_rb_param  0, field_info.return_types[0]
        stfld        field_info.clr_type + '::' + field_info.member_name  
        ldc_i4_Qnil
        ret
      else
        ld_this      klass
        ldfld        field_info.clr_type + '::' + field_info.member_name  
        ret_2rb      field_info
      end
    end
  end
  
  alias alias_method_missing method_missing
  
  def method_missing(method_name, *method_params, &block)
    member_info = get_instance_member_info(method_name.to_s)
    
    case member_info.member_type
    when 'method':       generate_method_shim(self.class, member_info)
    when 'fastmethod':   generate_fastmethod_shim(self.class, member_info)
    when 'property':     generate_method_shim(self.class, member_info)
    when 'fastproperty': generate_fastmethod_shim(self.class, member_info)
    when 'array':        generate_fastmethod_shim(self.class, member_info)
    when 'event':        return generate_event_shim(self.class, member_info, &block)
    when 'field':        generate_field_shim(self.class, member_info)
    end

    self.send member_info.ruby_member_name, *method_params
  end
  
  def class_name
    klass = self.class
    create_safe_ruby_instance_method(klass, 'class_name') do
      if klass.is_value_type? 
        ld_self
        box       klass.clr_type_name
      else
        ld_this   klass
      end
      call        'Object::GetType()'
      callvirt    'Type::get_FullName()'
      marshal2rb  'String'
      ret
    end
    class_name
  end
end

module ClrClassStaticMethods
  attr_reader :value_type_size, :clr_type_name
  
  def is_value_type?
    @is_value_type
  end
  
  def is_enum?
    @is_enum
  end
  
  def const_missing(symbol)
    clr_type_name, array_rank = parse_clr_class_reference(symbol.to_s)

    clr_namespace = self.name.gsub('::', '.')
    clr_type      = clr_namespace + '+' + clr_type_name
    clr_type     += "[#{',' * (array_rank - 1)}]" if array_rank > 0

    klass = create_clr_class_object(clr_type)
    klass.instance_variable_set('@event_refs', [])
    klass.is_enum? ? generate_enum_class_object(symbol, klass) : generate_class_object(clr_type, klass)

    self.const_set(symbol, klass)
  end
  
  def generate_static_fastmethod_shim(klass, method_info)
    create_safe_ruby_singleton_method(klass, method_info.member_name) do
      ld_params    method_info.signature 
      static_call  method_info
      ret_2rb      method_info
    end
  end
  
  def generate_static_method_shim(klass, method_info)
    static_method_labels = (1..method_info.signatures.length).collect { |i| ("l" + i.to_s).to_sym }
    
    create_safe_ruby_singleton_method(klass, method_info.member_name) do
      match_sig   method_info.member_id
      switch      static_method_labels
      throw_clr   'Cannot find method that matches Ruby parameters'
      
      method_info.signatures.each_with_index do |sig, i|
        label        static_method_labels[i]
        
        ld_params    sig
        static_call  method_info, sig
        ret_2rb      method_info, i
      end
    end
  end
  
  def generate_static_field_shim(klass, field_info)
    is_setter = field_info.ruby_member_name.rindex('=') == (field_info.ruby_member_name.length - 1)
    create_safe_ruby_singleton_method(klass, field_info.ruby_member_name) do
      if is_setter
        ld_rb_param  0, field_info.return_types[0]
        stsfld       'static ' + field_info.clr_type + '::' + field_info.member_name  
        ldc_i4_Qnil
        ret
      else
        ldsfld       'static ' + field_info.clr_type + '::' + field_info.member_name  
        ret_2rb      field_info
      end
    end
  end
  
  def method_missing(static_method_name, *static_method_params)
    static_member_info = get_static_member_info(static_method_name.to_s)
    
    case static_member_info.member_type
    when 'method':       generate_static_method_shim(self, static_member_info)
    when 'fastmethod':   generate_static_fastmethod_shim(self, static_member_info)
    when 'property':     raise 'Overloaded static properties are not supported by RubyCLR'
    when 'fastproperty': generate_static_fastmethod_shim(self, static_member_info)
    when 'field':        generate_static_field_shim(self, static_member_info)
    end
    
    self.send static_member_info.member_name, *static_method_params
  end
end

class Module
  def clr_type_names
    @clr_type_names == nil ? {} : @clr_type_names
  end

  def type_name_set(type_name)
    @clr_type_names ||= {}
    @clr_type_names[type_name] = true
  end

  def get_module_type_name_defined_in(type_name)
    ancestors.each { |a| return a if a.clr_type_names.has_key?(type_name) }
    nil
  end

  alias alias_const_missing const_missing

  def const_missing(symbol)
    clr_type_name, array_rank = parse_clr_class_reference(symbol.to_s)
    clr_module                = get_module_type_name_defined_in(clr_type_name)
    alias_const_missing(symbol) if clr_module == nil 

    clr_namespace = clr_module.name.gsub('::', '.')
    clr_type      = clr_namespace + '.' + clr_type_name
    clr_type     += "[#{',' * (array_rank - 1)}]" if array_rank > 0

    klass = create_clr_class_object(clr_type)
    klass.instance_variable_set('@event_refs', [])
    klass.is_enum? ? generate_enum_class_object(symbol, klass) : generate_class_object(clr_type, klass)

    clr_module.const_set(symbol, klass)
  end

  # This method de-mangles names - will add generics parsing to this later
  def parse_clr_class_reference(symbol)
    r = /(.*)_array_(\d+)/.match(symbol.to_s)
    return symbol, 0 if r == nil
    return r[1], Integer(r[2])
  end

  def generate_enum_class_object(symbol, klass)
    # TODO: rename values and lookup hashes to meaningful names
    klass.class_eval %{
      def self.initialize_lookups(hash, symbol_lookup)
        @@values = hash
        @@lookup = symbol_lookup
      end
      
      def self.lookup(value)
        @@lookup.has_key?(value) ? @@lookup[value] : #{symbol}.new(value)
      end
      
      def initialize(value)
        @value = value
      end
      
      def +(rhs)
        #{symbol}.new(@value + rhs)
      end
      
      def -(rhs)
        #{symbol}.new(@value - rhs)
      end
      
      def |(rhs)
        return #{symbol}.new(@value | rhs.to_i) if rhs.instance_of?(#{symbol})
        return #{symbol}.new(@value | rhs)      if rhs.instance_of?(Fixnum)
        raise 'Enum bitwise or operator can only work with ' + #{symbol} + ' or Fixnum types'
      end
      
      def to_i
        @value
      end
      
      def to_s
        @@values.has_key?(@value) ? @@values[@value] : @value.to_s
      end
      
      def ==(rhs)
        @value == rhs.to_i
      end
    }

    enum_names  = get_enum_names(klass)
    enum_values = get_enum_values(klass)
    raise "Should never happen: names and values counts for #{clr_type} do not match" if enum_names.length != enum_values.length
    
    hash, symbol_lookup = {}, {}
    0.upto(enum_names.length - 1) do |i|
      hash[enum_values[i]]          = enum_names[i]
      enum_instance                 = klass.new(enum_values[i])
      symbol_lookup[enum_values[i]] = enum_instance
      klass.const_set(enum_names[i], enum_instance)
    end
    klass.initialize_lookups(hash, symbol_lookup)
  end

  def generate_class_object(clr_type, klass)
    klass.class_eval %{
      include ClrClassInstanceMethods
      extend  ClrClassStaticMethods
    }
  end
end

module RubyClr
  @@type_ref_re = /^([\w0-9\_\.]+)\.([\w0-9\_]+)$/

  def self.get_namespace(namespace)
    scope = Object
    namespace.split('.').each do |n|
      scope = scope.const_defined?(n) ? scope.const_get(n) : scope.const_set(n, Module.new)
    end
    scope
  end

  def self.generate_modules(class_names)
    class_names.each do |c|
      m = @@type_ref_re.match(c)
      if m != nil
        namespaces, type_name = m[1], m[2]
        begin
          scope = get_namespace(namespaces)
          scope.type_name_set(type_name) if scope != nil
        rescue
          # swallow parse errors for now
        end
      end
    end
  end

  def self.init
    generate_modules(get_types_in_loaded_assemblies)
  end

  def self.reference(assembly_name)
    generate_modules(internal_reference(assembly_name))
  end

  def self.reference_file(assembly_path)
    generate_modules(internal_reference_file(assembly_path))
  end
end

RubyClr::init
