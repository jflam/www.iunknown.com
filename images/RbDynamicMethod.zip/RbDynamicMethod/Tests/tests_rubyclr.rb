require 'rubyclr'
require 'test/unit'
include RubyClr

RubyClr::reference_file 'RubyClrTests.dll'
RubyClr::reference 'System.Windows.Forms'
RubyClr::reference 'System.Drawing'

include System
include System::Collections
include System::Drawing
include RubyClr::Tests

class ConstructorTests < Test::Unit::TestCase
  def test_default_ctor
    assert_equal 'System.Collections.ArrayList', ArrayList.new.class_name
  end

  def test_single_arg_ctor
    assert_equal 'System.Collections.ArrayList', ArrayList.new(42).class_name
  end

  def test_fail_multi_arg_ctor
    assert_raises RuntimeError do
      ArrayList.new(42, 42, 42) 
    end
  end

  def test_stack_default_ctor
    assert_equal 'System.Collections.Stack', Stack.new.class_name
  end
end

class MarshalerTests < Test::Unit::TestCase
  def test_marshal_integers
    a = ArrayList.new
    a.Add(0)
    a.Add(-1)
    a.Add(2^32)
    a.Add(2^63)
    assert_equal 0, a.get_Item(0)
    assert_equal -1, a.get_Item(1)
    assert_equal 2^32, a.get_Item(2)
    assert_equal 2^63, a.get_Item(3)
  end

  def test_marshal_floating_point
    a = ArrayList.new
    a.Add(3.1415926)
    a.Add(2.18281828)
    assert_equal 3.1415926, a.get_Item(0)
    assert_equal 2.18281828, a.get_Item(1)
  end

  def test_marshal_boolean
    a = ArrayList.new
    a.Add(true)
    a.Add(false)
    assert_equal true, a.get_Item(0)
    assert_equal false, a.get_Item(1)
  end

  def test_marshal_strings
    a = ArrayList.new
    a.Add('John')
    a.Add('Jacob')
    assert_equal 'John', a.get_Item(0)
    assert_equal 'Jacob', a.get_Item(1)
  end

  def test_marshal_objref
    p = System::MarshalerTests.new.GetPerson
    assert_equal 'John', p.Name
  end
end

class MethodTests < Test::Unit::TestCase
  def test_count_method
    assert_equal 0, ArrayList.new.get_Count
  end

  def test_add
    a = ArrayList.new
    assert_equal 0, a.Add(42)
    assert_equal 1, a.Add('Two')
    assert_equal 2, a.get_Count
    assert_equal 42, a.get_Item(0)
    assert_equal 'Two', a.get_Item(1)
  end
end

class PropertyTests < Test::Unit::TestCase
  def test_count_method
    assert_equal 0, ArrayList.new.get_Count
  end

  def test_count_property
    assert_equal 0, ArrayList.new.Count
  end

  def test_get_indexer
    a = ArrayList.new
    a.Add(42)
    a.Add('John')
    assert_equal 42, a[0]
    assert_equal 'John', a[1]
  end

  def test_set_indexer
    a = ArrayList.new
    a.Add(42)
    assert_equal 42, a[0]
    a[0] = 'John'
    assert_equal 'John', a[0]
  end

  def test_property_overload_resolution
    o = System::PropertyOverloads.new
    o[4] = 42
    o['5'] = 43
    assert_equal 42, o[4]
    assert_equal 43, o[5]
    assert_equal 42, o['4']
    assert_equal 43, o['5']
  end

  def test_static_property
    assert_equal 0, System::PropertyOverloads.StaticProperty
    System::PropertyOverloads.StaticProperty = 42
    assert_equal 42, System::PropertyOverloads.StaticProperty
  end

  def test_static_non_default_overloaded_property
    assert_raises RuntimeError do
      System::PropertyOverloads.OverloadedProperty[42]
    end
  end
end

class StaticMethodTests < Test::Unit::TestCase
  def test_static_method
    a = System::MarshalerTests.StaticGetOneDimensionalArray
    assert_equal 4, a.Length
    assert_equal 1, a.Rank
  end

  def test_static_method_overload_resolution
    p1 = System::Person.Create
    p2 = System::Person.Create('Mike')
    assert_equal 'John', p1.Name
    assert_equal 'Mike', p2.Name
  end
end

class ArrayTests < Test::Unit::TestCase
  def test_one_dimensional_array
    a = System::MarshalerTests.new.GetOneDimensionalArray
    assert_equal 4, a.Length
    assert_equal 1, a.Rank
    assert_equal 0, a.GetValue(0) # this returns a value type that is a boxed integer!
    assert_equal 0, a[0]
    assert_equal 1, a[1]
  end

  def test_two_dimensional_array
    a = System::MarshalerTests.StaticGetTwoDimensionalArray
    assert_equal 0, a.GetValue(0, 0)
    assert_equal 2, a.Rank
    assert_equal 2, a.GetLength(0)
    assert_equal 2, a.GetLength(1)
    assert_equal 0, a[0, 0]
    assert_equal 1, a[0, 1]
    assert_equal 1, a[1, 0]
    assert_equal 0, a[1, 1]
  end

  def test_three_dimensional_array
    a = System::MarshalerTests.StaticGetThreeDimensionalArray
    assert_equal 3, a.Rank
    assert_equal 2, a.GetLength(0)
    assert_equal 2, a.GetLength(1)
    assert_equal 2, a.GetLength(2)
    assert_equal 0, a[0, 0, 0]
    assert_equal 1, a[0, 0, 1]
    assert_equal 0, a[1, 0, 0]
  end
end

class EventTests < Test::Unit::TestCase
  def test_simple_event
    c = System::CallbackTests.new('John')
    c.Event do |sender, args|
      assert_equal 1, 1
    end
    c.CallMeBack
  end

  def test_event_parameter_marshaling
    c = System::CallbackTests.new('Mike')
    assert_equal 'Mike', c.Name
    c.Event do |sender, args|
      assert_equal 'Mike', sender.Name
    end
    c.CallMeBack
  end

  def test_value_type_parameter_marshaling
    c = System::DelegateCalc.new(3, 4)
    c.AddResult do |sender, result|
      assert_equal 7, result
    end
    c.Add
  end
end

class FieldTests < Test::Unit::TestCase
  def test_field_read
    m = System::MarshalerTests.new
    assert_equal 'Hello', m.Name
  end

  def test_field_write
    m = System::MarshalerTests.new
    m.Name = 'John'
    assert_equal 'John', m.Name
  end
end

class ValueTypeTests < Test::Unit::TestCase
  def test_get_value_type
    p = System::MarshalerTests.GetPoint
    assert_equal 3, p.X
    assert_equal 4, p.Y
    assert_equal 'System.Drawing.Point', p.class_name
  end

  def test_call_value_type_instance_method
    p = System::MarshalerTests.GetPoint
    p.Offset(1, 1)
    assert_equal 4, p.X
    assert_equal 5, p.Y
  end

  def test_create_value_type
    p = Point.new(3, 4)
    assert_equal 3, p.X
    assert_equal 4, p.Y
  end

  def test_marshal_value_type_to_clr
    p1 = Point.new(2, 3)
    s1 = Size.new(p1)
    assert_equal s1.Width, p1.X
    assert_equal s1.Height, p1.Y
  end

  def test_point_clone
    p1 = Point.new(3, 4)
    assert_equal 3, p1.X
    assert_equal 4, p1.Y
    p2 = p1.clone
    assert_equal p1.X, p2.X
    assert_equal p1.Y, p2.Y
    p1.X += 1
    assert_equal p1.X, p2.X + 1
  end

  def test_instance_variable_clone
    p1 = Point.new(3, 4)
    p1.instance_variable_set('@name', 'bob')
    p2 = p1.clone
    p1.instance_variable_set('@name', 'mike')

    assert_equal 'bob', p2.instance_variable_get('@name')
    assert_equal 'mike', p1.instance_variable_get('@name')
    assert_equal 3, p2.X
    assert_equal 4, p2.Y
  end
end

class EnumTests < Test::Unit::TestCase
  include System::Windows::Forms
  def test_enum
    k = DialogResult::Abort
    assert_equal DialogResult::Abort, k
    assert_equal 'Abort', k.to_s
    assert_equal 3, k.to_i
  end
end

class MethodOverloadTests < Test::Unit::TestCase
  def test_overloads
    o = System::MethodOverloads.new
    assert_equal 1, o.Method(1, 'x')
    assert_equal 2, o.Method('x', 'x')
  end
end

# This test case catches the nastiest bug in RubyCLR - I had assumed that covariance wasn't possible, but it is if the param
# signatures disambiguate the methods. So while you can't have
# int Add(string) and int Add(int)
#
# you CAN have:
# int Add(string) and string Add(int)
#
# This is used in a few places in the .NET Frameworks, most notably in DataColumnCollection.Add()
#
# This bug presented itself initially as a hard crash with a corrupted stack. It wasn't until I looked via Reflector that 
# I realized that it was this form of covariance that caused the hard crash. This required a major pass through a lot of 
# code in RubyCLR, both C++ and Ruby. This assumption was buried in a number of places, but in the end I was happy with
# how little time it took (about 30 min) once I had figured out the root cause of the problem.
#
# This goes to show how the best debugger you have is between your ears - had I tried to track down the root cause of 
# the stack corruption, I may have found this bug eventually, but it would have taken a LONG time since where it crashed
# was in a fairly unrelated place.

class CoVarianceTests < Test::Unit::TestCase
  include System
  def test_instance_methods
    o = CoVarianceTarget.new
    assert_equal 1, o.Method('1')
    assert_equal '1', o.Method(1)
  end

  def test_static_methods
    assert_equal 1, CoVarianceTarget.StaticMethod('1')
    assert_equal '1', CoVarianceTarget.StaticMethod(1)
  end  
end

# This bug (or missing feature) forced me into a major refactoring that had the really nice performance side-effect
# of eliminating most of the code from a class_eval method call that I used to inject instance and static methods into
# the Ruby CLR shadow class. This makes debugging much easier since the line numbers actually match up, and the bizarro
# string stuff that I had to do can now be replaced by the much cleaner "text #{expression}" expressions.

class NestedClassTests < Test::Unit::TestCase
  include System
  def test_nested_class_resolution
    assert_equal 42, ParentClass::NestedClass.Method
  end
end

class SimpleBindTests < Test::Unit::TestCase
  def test_bind_string
    assert_equal 'Hello', BindingTestClass.Bind('Hello')
  end

  def test_bind_int
    assert_equal 10, BindingTestClass.Bind(10)
  end

  def test_bind_boolean
    assert_equal false, BindingTestClass.Bind(false) 
  end
end

class InheritedBindTests < Test::Unit::TestCase
  def setup
    @b = InheritedBindingSub.new
  end
  
  def test_bind_string
    assert_equal 'Subclass string', @b.Bind('Hi')
  end

  def test_bind_int
    assert_equal 'Subclass int', @b.Bind(10)
  end

  def test_bind_boolean
    assert_equal 'Subclass bool', @b.Bind(true)
  end
end

class DispatchTests < Test::Unit::TestCase
  def setup
    @d = Dispatch.new
  end

  def check(expected_value)
    Dispatch.Flag = 0
    yield if block_given?
    assert_equal expected_value, Dispatch.Flag
  end

  def test_enum_overloads
    check(101) { @d.M1(1) }
    check(201) { @d.M1(DispatchHelpers::Color::Red) }
  end

  def test_enum_implicit_conversion_to_integer
    check(111) { @d.M11(1, 1) }
    check(211) { @d.M11(DispatchHelpers::Color::Red, 1) }
    # todo: make these pass!
    # check(111) { @d.M11(1, DispatchHelpers::Color::Red) }
    # check(211) { @d.M11(DispatchHelpers::Color::Red, DispatchHelpers::Color::Red) }
  end

  def test_integer_param_array
    check(102) { @d.M2(1) }
    # todo: overload resolution algorithm with int param array
  end

  def test_simple_overload
    check(103) { @d.M3(1) }
    check(203) { @d.M3(1, 1) }
  end

  def ztest_float_vs_single_overload
    # NOTE: There is no way for me to represent the result of Single.Parse as anything but a double, since I convert it
    # into a Ruby float value when marshaling back to Ruby. Short of annotating the float object, (maybe in the future?)
    # I can't see a way to make that work. Even if I did do this, would it actually be useful to anyone???
    check(205) { @d.M5(Single.Parse("3.14")) }
    check(205) { @d.M5(3.14) }
  end

  def test_reference_parameters
    # todo: implement out params!
  end

  # todo: overload resolution must take into consideration both static and instance methods- don't do this yet!
  def ztest_m81 # static vs. instance overloads ... nasty!
    check(181) { @d.M81(@d, 1) }
  end

  def test_pass_null
    check(120) { @d.M20(nil) }
  end

  def test_overload_with_derived_types
    check(122) { @d.M22(DispatchHelpers::B.new) }
    check(222) { @d.M22(DispatchHelpers::D.new) }
  end

  def test_implicit_upcast_to_interface
    # todo: this is an implicit upcast to an interface - overload resolution algorithm clearly doesn't handle this yet
    #    check(123) { @d.M23(DispatchHelpers::C1.new) }
    check(223) { @d.M23(DispatchHelpers::C2.new) }    
  end

  def test_nullable_types
  end

  def test_m82
    check(182) { Dispatch.M82(true) }
    check(282) { Dispatch.M82('true') }
    # todo: failures while calling via objref must be marshaled correctly to Ruby RuntimeErrors (right now CLR exceptions blow up process)
  end
end
