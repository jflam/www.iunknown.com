require 'winforms'

class MainForm
  CS  = 'server=.\SQLEXPRESS;database=adventureworks;integrated security=sspi'
  SQL = 'select * from humanresources.employee'

  def create_form(grid)
    form               = Form.new
    form.Text          = 'Windows Forms in Ruby'
    form.AutoScaleMode = AutoScaleMode::Font
    form.ClientSize    = Size.new(292, 266)
    form.Controls.Add(grid)
    form.Load do |sender, args|
      adapter = SqlDataAdapter.new(SQL, CS)
      ds      = DataSet.new
      adapter.Fill(ds, 'Employee')
      grid.DataSource = ds
      grid.DataMember = 'Employee'
    end
    form
  end

  def create_gridview
    grid = DataGridView.new
    grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode::AutoSize
    grid.Dock     = DockStyle::Fill
    grid.Location = Point.new(0, 0)
    grid.Size     = Size.new(292, 266)
    grid.TabIndex = 0
    grid
  end

  def initialize
    @grid = create_gridview
    @form = create_form(@grid)
  end
end

WinFormsApp.Run(MainForm)
