require 'winforms'

RubyClr::reference 'System.Xml'

include System::Collections
include System::IO
include System::Xml

def auto_dispose(obj)
  yield obj if block_given?
  obj.Dispose
end

def auto_close(obj)
  yield obj if block_given?
  obj.Close
end

def marshal_to_data_table(array)
  dt = DataTable.new
  raise 'array must have at least one element' if array.length < 1
  schema = array[0].members
  schema.each { |member| dt.Columns.Add(member) }
  array.each do |element|
    row = dt.NewRow
    schema.each { |column_name| row[column_name] = element.send column_name }
    dt.Rows.Add(row)
  end
  dt
end

RssItem = Struct.new :title, :link, :description, :attributes

class RssFeed < RssItem
  def read_item(r, name)
    end_found = false
    item = RssItem.new
    while !end_found and r.Read
      if r.NodeType == XmlNodeType::EndElement and r.LocalName.downcase == name
        end_found = true
      elsif r.NodeType == XmlNodeType::Element
        item.attributes ||= {}
        item.attributes[r.LocalName] = r.ReadString
      end
    end
    item
  end    

  def initialize(path)
    auto_close(XmlTextReader.new(path)) do |r|
      found_channel = false
      while r.Read
        local_name = r.LocalName.downcase
        if r.NodeType == XmlNodeType::Element
          if !found_channel
            channel_found = true if local_name == 'channel'
          elsif local_name == 'item'
            read_item(r, 'item')
          elsif local_name == 'image'
            read_item(r, 'image')
          else
            if r.MoveToContent == XmlNodeType::Element
              content = r.ReadString
              if r.nodeType == XmlNodeType::EndElement
                self.attributes ||= {}
                self.attributes[r.LocalName] = content
              end
            end
          end
        end
      end
    end
  end
  end

class RssLinks
  def self.load(path)
    a = ArrayList.new
    auto_dispose(StreamReader.new(FileStream.new(path, FileMode::Open))) do |r|
      a.Add(r.ReadLine) while !r.EndOfStream
    end
    a
  end
end

class MainForm
  def initialize
    form = Form.new
    form.Text = 'Ruby RSS Reader'
    form.Size = Size.new(831, 500)

    top_panel = Panel.new
    top_panel.Dock = DockStyle::Top
    top_panel.Location = Point.new(0, 72)
    top_panel.Size = Size.new(831, 52)

    form.Controls.Add(top_panel)

    menu = MenuStrip.new
    menu.BackColor = Color.FromArgb(91, 91, 91)
    menu.ForeColor = Color.White

    menu.Items.Add('File')
    menu.Items.Add('Options')
    menu.Items.Add('Help')
    menu.Location = Point.new(0, 0)
    menu.Size = Size.new(831, 24)

    form.Controls.Add(menu)

    label2 = Label.new
    label2.Location = Point.new(14, 21)
    label2.Text = '&Choose a Feed:'

    top_panel.Controls.Add(label2)

    combo_box = ComboBox.new
    combo_box.Location = Point.new(118, 17)
    combo_box.Size     = Size.new(210, 21)
    combo_box.ValueMember = 'URL'
    combo_box.DisplayMember = 'Title'
    combo_box.FormattingEnabled = true

    top_panel.Controls.Add(combo_box)

    choose_feed_button = Button.new
    choose_feed_button.Size = Size.new(32, 23)
    choose_feed_button.Location = Point.new(337, 16)
    choose_feed_button.Text = 'Go'
    choose_feed_button.Click do |sender, args|
      MessageBox.Show('clicked on Go!')
    end

    top_panel.Controls.Add(choose_feed_button)

    form.Load do |sender, args|
      combo_box.DataSource = RssLinks.load('.\links.dat')
      feed = RssFeed.new('.\LessIsBetter.xml')
    end

    @form = form
  end
end

WinFormsApp.Run(MainForm)
