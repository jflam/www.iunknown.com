require 'rubyclr'

RubyClr::reference 'System.Data'
RubyClr::reference 'System.Drawing'
RubyClr::reference 'System.Windows.Forms'

include System
include System::Data
include System::Data::SqlClient
include System::Drawing
include System::Windows::Forms

class MainForm
  attr_reader :form
end

module WinFormsApp
  include System::Windows::Forms

  def self.Run(klass)
    Application.EnableVisualStyles
    Application.SetCompatibleTextRenderingDefault false
    Application.Run(klass.new.form)
  end
end
