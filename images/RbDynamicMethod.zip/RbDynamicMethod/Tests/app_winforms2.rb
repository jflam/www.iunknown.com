require 'winforms'

class MainForm
  def initialize
    @form = Form.new
    @form.Text = 'Ruby Windows Forms'

    @label = Label.new
    @label.AutoSize = true
    @label.Location = Point.new(21, 22)
    @label.Text     = 'Phone: '
    @label.TabIndex = 0
    @label.Size     = Size.new(35, 13)

    @textbox = TextBox.new
    @textbox.Location = Point.new(62, 19)
    @textbox.Size     = Size.new(100, 20)
    @textbox.Text     = 'Default text'
    @textbox.TabIndex = 1

    @button = Button.new
    @button.Location  = Point.new(184, 17)
    @button.Size      = Size.new(75, 23)
    @button.TabIndex  = 2
    @button.Text      = 'OK'
    @button.UseVisualStyleBackColor = true
    
    @form.Controls.Add(@label)
    @form.Controls.Add(@textbox)
    @form.Controls.Add(@button)

    @button.Click do |sender, args|
      MessageBox.Show("Entered: #{@textbox.Text}")
    end
  end
end

WinFormsApp.Run(MainForm)
